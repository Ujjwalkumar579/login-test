<?php
session_start();
if(isset($_SESSION['email'])){
    header('Location: dashboard.php');
}
$conn=mysqli_connect("localhost", "root", "", "classroom");
if(isset($_POST['login'])){
    $email=$_POST['email'];
    $password=$_POST['password'];

    $sql="SELECT * FROM users WHERE BINARY email='$email' and BINARY password='$password'";
    $result=mysqli_query($conn, $sql);
    $row=mysqli_num_rows($result);
    if($row==1){
        $_SESSION['email']=$email;
        header('Location: dashboard.php');
    }else{
        echo "Invalid Username or Password!";
    }
}
?>
<!DOCTYPE html>
<html lang="">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
</head>

<body>
    
    <form action="" method="post" autocomplete="off">
        <input type="text" name="email" placeholder="Username"><br><br>
        <input type="text" name="password" placeholder="Password"><br><br>
        <input type="submit" value="Login" name="login">
    </form>
    
</body>
</html>