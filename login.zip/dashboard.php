<?php
session_start();
if(!$_SESSION['email']){
    header('Location: login.php');
}
$e=$_SESSION['email'];
?>
<!DOCTYPE html>
<html lang="">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
</head>

<body>
    
    <h2>Login Success!</h2>

    <?php
    $conn=mysqli_connect("localhost", "root", "", "classroom");
    $sql="SELECT * FROM users WHERE email='$e'";
    $result=mysqli_query($conn, $sql);
    $row=mysqli_fetch_assoc($result);
    echo "Name: $row[fname]";
    ?>

    <a href="logout.php">Logout</a>
    
</body>
</html>